package controller;

import model.Estudiante;
import java.util.ArrayList;

public class controlador {
	
	private ArrayList<Estudiante> arregloEstudiantes;
	
	public controlador() {
		this.arregloEstudiantes=new ArrayList<Estudiante>();
	}
	
	public void MundoEstudiante(String EntradaNombre, String EntradaApellidos, String EntradaEdad, String EntradaCodigo, String EntradaGenero) {
		
		Estudiante objetoEstudiante=new Estudiante();				
		
		objetoEstudiante.setNombre(EntradaNombre);
		objetoEstudiante.setApellidos(EntradaApellidos);
		objetoEstudiante.setEdad(Integer.valueOf(EntradaEdad));
		objetoEstudiante.setCodigo(EntradaCodigo);
		objetoEstudiante.setGenero(EntradaGenero);
		
		this.arregloEstudiantes.add(objetoEstudiante);		
	}	
	
	public ArrayList<Estudiante> retornoEstudiante(){
		//System.out.println ("retornando a "+this.arregloEstudiantes.get(0));
		return this.arregloEstudiantes;
	}
}
