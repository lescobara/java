package model;

public class Estudiante extends Persona{
	
	//Declaraci?n de atributos
	private String codigo;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
}
