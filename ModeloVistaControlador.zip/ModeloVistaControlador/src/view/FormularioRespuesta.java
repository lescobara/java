package view;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Estudiante;

import java.util.ArrayList;


public class FormularioRespuesta extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		
	public FormularioRespuesta(ArrayList <Estudiante> fuenteEstudiante)
	{
		
		
		super("Formulario Respuesta");
		
		getContentPane().setLayout(null);
		
		JFrame f=new JFrame();
		JPanel panel=new JPanel();
		
		DefaultTableModel model = new DefaultTableModel();
		
		model.addColumn("Nombre");
		model.addColumn("Apellido");
		model.addColumn("Edad");
		model.addColumn("Código");
		model.addColumn("Género");
		
		for (int i=0; i<fuenteEstudiante.size();i++) {
			model.addRow(new String[] {fuenteEstudiante.get(i).getNombre(),fuenteEstudiante.get(i).getApellidos(),String.valueOf(fuenteEstudiante.get(i).getEdad()),fuenteEstudiante.get(i).getCodigo(),fuenteEstudiante.get(i).getGenero()});
			//System.out.println(fuenteEstudiante.get(i).getNombre());
		}
		
		JTable table = new JTable(model); 
		
		panel.add(new JScrollPane(table));
		f.add(panel);

		f.setVisible(true);
		f.setSize(470,300);
	}
	
}
