package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import controller.controlador;

public class BuscarPerformed implements ActionListener{
	
	private controlador objetoTemp;
	
	public BuscarPerformed (controlador entradaControlador) {
		this.objetoTemp=entradaControlador;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		FormularioRespuesta objetoRespuesta=new FormularioRespuesta(objetoTemp.retornoEstudiante());		
	}

}
