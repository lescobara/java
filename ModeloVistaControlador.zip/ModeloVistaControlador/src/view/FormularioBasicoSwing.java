package view;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import controller.controlador;

public class FormularioBasicoSwing extends JFrame implements ActionListener
{
	private controlador objetoControlador;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//Declaro atributos en donde se guardar� los valores digitados
	private JTextField textfield,textfield2,textfield3,textfield4;
	private JRadioButton masculinoButton,femeninoButton;
	
	//creamos el constructor
	public FormularioBasicoSwing() {
		  super("Formulario Básico");
		  this.objetoControlador=new controlador();
		  getContentPane().setLayout(new FlowLayout());
		  
		  //Creando campos del formulario
		  JLabel label = new JLabel("Digita Nombre:");
		  textfield = new JTextField(20);
		  JLabel label2 = new JLabel("Digita Apellidos:");
		  textfield2 = new JTextField(20);
		  JLabel label3 = new JLabel("Digita Edad:");
		  textfield3= new JTextField(5);
		  JLabel label4 = new JLabel("Digita Código");
		  textfield4= new JTextField(8);
		  //Creando los Radio Buttons para seleccionar g�nero
		  JLabel label5 = new JLabel("Selecciona Género");
		  masculinoButton   = new JRadioButton("Masculino");
		  femeninoButton   = new JRadioButton("Femenino");
		  //Creando Bot�n y a�adiendo el listener	 
		  JButton boton = new JButton("Ingresar");
		  boton.addActionListener((ActionListener) this);

		  JButton boton2 = new JButton("Mostrar");
		  BuscarPerformed objetoBuscar=new BuscarPerformed(this.objetoControlador);
		  boton2.addActionListener(objetoBuscar);
		  
		  
		  //A�adiendo componentes
		  getContentPane().add(label);
		  getContentPane().add(textfield);
		  getContentPane().add(label2);
		  getContentPane().add(textfield2);
		  getContentPane().add(label3);
		  getContentPane().add(textfield3);
		  getContentPane().add(label4);
		  getContentPane().add(textfield4);
		  getContentPane().add(label5);
		  getContentPane().add(masculinoButton);
		  getContentPane().add(femeninoButton);
		  getContentPane().add(boton);
		  getContentPane().add(boton2);
		  
		  setSize(400,300);
		  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
	
	//M�todo declarado para activar el Listener
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
		//Al momento de oprimir el bot�n se crea un objeto de la clase estudiante
		//controlador objetoControlador=new controlador();
		this.objetoControlador.MundoEstudiante(textfield.getText(), textfield2.getText(), textfield3.getText(), textfield4.getText(), this.selectorGenero());
		JOptionPane.showMessageDialog(this, "Valor ingresado Exitosamente");
	}
	
	//Metodo declarado para asignar el valor del g�nero
	public String selectorGenero(){
		//Declaro Variable privada del m�todo
		String genero;
		
		/*Si el radio button masculino es seleccionado
		 * entonces el valor de la variable es 
		 * Masculino y retorno la variable*/
		
		if (masculinoButton.isSelected()==true)
		{
			genero="Masculino";
		}
		else
		{
			genero="Femenino";
		}
		return genero;
	}
	
	//M�todo PPAL
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			FormularioBasicoSwing objeto=new FormularioBasicoSwing();
			objeto.setVisible(true);
		}

}
