package paquete2;

public class OperacionesMatematicas {
	
	//Método que retorna la suma
	public int suma (int entrada1,int entrada2) {
		return entrada1+entrada2;
	}
	
	//Método que retorna la resta
	public int resta (int entrada1,int entrada2) {
		return entrada1-entrada2;
	}
	
	//Método que me retorna la multiplicación
	public int multiplicacion (int entrada1,int entrada2) {
		return entrada1*entrada2;
	}

}
