package paquete2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ClasePrincipal {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		MenuCalculadora objeto=new MenuCalculadora();
		objeto.generarMenu();
		
		//Capturar el dato de entrada empleando desde Buffered reader
		BufferedReader objetoEntrada=new BufferedReader(new InputStreamReader(System.in));
		String entrada=objetoEntrada.readLine();
		
		//pasar de tipo de dato String a tipo de dato Entero
		
		objeto.seleccionarMetodo(Integer.parseInt(entrada));

	}

}
