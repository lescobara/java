package paquete2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MenuCalculadora {

	public void generarMenu() {
		System.out.println("BIENVENIDOS A MI PROGRAMA");
		System.out.println("Por favor digite el numero de la operacion que desea realizar");
		System.out.println("1. SUMA");
		System.out.println("2. Resta");
		System.out.println("3. Multiplicacion");
	}
	
	public void seleccionarMetodo(int entradaConsola) throws IOException {
		//Instanciar el objeto BufferedReader para capturar desde la consola
		BufferedReader objetoEntrada=new BufferedReader(new InputStreamReader(System.in));
		String entradaConsola1,entradaConsola2,continuar="s";
		
		//Crear objeto del tipo clase OperacionesMatematicas
		OperacionesMatematicas objetoOperaciones=new OperacionesMatematicas();
		
		switch (entradaConsola) {
		case 1:
			while (continuar.equals("s")) {
				System.out.println("Por favor digite el primer valor");
				entradaConsola1=objetoEntrada.readLine();
				System.out.println("Por favor digite el segundo valor");
				entradaConsola2=objetoEntrada.readLine();
				//Invoco el método que hace la suma
				int resultadoSuma=objetoOperaciones.suma(Integer.parseInt(entradaConsola1),Integer.parseInt(entradaConsola2));
				System.out.println("El resultado de la suma es"+resultadoSuma);
				System.out.println("Desea hacer otra suma");
				continuar=objetoEntrada.readLine();
			}	
			if (continuar.equals("s")) {
				seleccionarMetodo(1);
			}
			else {
			break;
			}
		case 2:
			System.out.println("Por favor digite el primer valor");
			entradaConsola1=objetoEntrada.readLine();
			System.out.println("Por favor digite el segundo valor");
			entradaConsola2=objetoEntrada.readLine();
			//Invoco el método que hace la resta
			int resultadoResta=objetoOperaciones.resta(Integer.parseInt(entradaConsola1),Integer.parseInt(entradaConsola2));
			System.out.println("El resultado de la resta es"+resultadoResta);
			break;
		
		case 3:
			System.out.println("Digite el primer valor");
			entradaConsola1=objetoEntrada.readLine();
			System.out.println("Digite el Segundo valor");
			entradaConsola2=objetoEntrada.readLine();
			int resultadoMultiplicacion=objetoOperaciones.multiplicacion(Integer.parseInt(entradaConsola1), Integer.parseInt(entradaConsola2));
			System.out.println("El resultado de la multiplicacion es:"+resultadoMultiplicacion);
			break;
		default:
			System.out.println("Operacion NO definida");
		}
	}
	
}
