package herencia;

public class AutomovilDeportivo extends ClasePadreAutomovil{

	private boolean turbo;
	
	/*Como mi clase Hijo (AutomovilDeportino) hereda también el constructor de la clase padre
	 * entonces se debe crear un constructor en la clase hijo que reciba las mismas entradas que
	 * la clase padre*/
	
	public AutomovilDeportivo(String entradaMarca, double entradaCilindraje, int entradaCantidadPuertas, boolean entradaTurbo) {
		//inicializo los atributos de la clase padre
		super(entradaMarca, entradaCilindraje, entradaCantidadPuertas);
		// TODO Auto-generated constructor stub
		
		//Inicializo el atributo de la clase hijo
		this.turbo=entradaTurbo;
	}

	public boolean getTurbo() {
		return turbo;
	}

	public void setTurbo(boolean turbo) {
		this.turbo = turbo;
	}
	
	

}
