package herencia;

public class ClasePadreAutomovil {
	
	//Declaración de atributos
	private String marcaCarro;
	private double cilindraje;
	private int cantidadPuertas;
	
	
	/*Esto en JAVA se conoce como un constructor*/
	public ClasePadreAutomovil(String entradaMarca,double entradaCilindraje,int entradaCantidadPuertas) {
		//Lo que estoy haciendo en el constructor es INICIALIZAR atributos
		this.marcaCarro=entradaMarca;
		this.cilindraje=entradaCilindraje;
		this.cantidadPuertas=entradaCantidadPuertas;
	}
	
	//Declaración de métodos
	
	public void arrancar(boolean estadoCarro) {
		if (estadoCarro==true) {
			System.out.println("El carro va arrancar");
		}
		else {
			System.out.println("El carro no puede arrancar");
		}
	}	
	
	public void detener(int velocidadCarro) {
		
		while (velocidadCarro!=0) {
			velocidadCarro=velocidadCarro-10;
			System.out.println("Deteniendo el carro, la velocidad actual es:"+velocidadCarro);
		}
	
		
	}

	//Métdodos Get y Set Autogenerados
	public String getMarcaCarro() {
		return marcaCarro;
	}

	public void setMarcaCarro(String marcaCarro) {
		this.marcaCarro = marcaCarro;
	}

	public int getCantidadPuertas() {
		return cantidadPuertas;
	}

	public void setCantidadPuertas(int cantidadPuertas) {
		this.cantidadPuertas = cantidadPuertas;
	}

	public double getCilindraje() {
		return cilindraje;
	}

	public void setCilindraje(float cilindraje) {
		this.cilindraje = cilindraje;
	}
	

}
