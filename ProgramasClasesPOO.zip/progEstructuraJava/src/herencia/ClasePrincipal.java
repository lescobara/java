package herencia;

public class ClasePrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//1. Crear el objeto de mi clase
		ClasePadreAutomovil objetoCarro=new ClasePadreAutomovil("Ferrari",1.8,4);
		
		//2. Para acceder al atributo invoco la clase get (obtener)
		String retorno=objetoCarro.getMarcaCarro();
		System.out.println("La marca del carro es: "+retorno);
		
		System.out.println("El cilindraje del carro es: "+objetoCarro.getCilindraje());
		
		System.out.println("La cantidad de puertas del carro es: "+objetoCarro.getCantidadPuertas());
		
		//Crear un objeto de la clase hijo
		AutomovilDeportivo objetoDeportivo=new AutomovilDeportivo("Maserati",4,2,true);
		
		System.out.println("La marca del segundo automovil es:"+objetoDeportivo.getMarcaCarro());
		System.out.println("El cilindraje del segundo carro es:"+objetoDeportivo.getCilindraje());
		System.out.println("La cantidad de puertas es:"+objetoDeportivo.getCantidadPuertas());
		System.out.println("El segundo carro tiene turbo"+objetoDeportivo.getTurbo());

	}

}
