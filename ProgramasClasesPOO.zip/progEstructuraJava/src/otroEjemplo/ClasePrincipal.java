package otroEjemplo;

public class ClasePrincipal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu objetoMenu=new Menu();
		
		objetoMenu.preguntarDatosPersonales();
		objetoMenu.preguntarPreguntas();
		objetoMenu.mostrarRespuestas();

	}

}
