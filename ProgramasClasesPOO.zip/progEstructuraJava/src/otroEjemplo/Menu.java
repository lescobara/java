package otroEjemplo;

import javax.swing.JOptionPane;

public class Menu {
	
	Persona atributoPersona;
	Preguntas atributoPregunta;
	
	/**
	 * Esta clase se encargará de preguntar los datos personales
	 * y de hacer las preguntas**/
	
	//Crear método para la toma de los datos personales
	
	public void preguntarDatosPersonales() {
		//Creo un objeto de la clase persona
		Persona objetoPersona=new Persona();
		String temporalNombre=JOptionPane.showInputDialog(null,"Ingrese el nombre");
		//PAso de Mensaje
		objetoPersona.setNombre(temporalNombre);
		
		String temporalApellido=JOptionPane.showInputDialog(null,"Ingrese el apellido");
		objetoPersona.setApellido(temporalApellido);
		
		int temporalEdad=Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese Su edad"));
		objetoPersona.setEdad(temporalEdad);
		
		int temporalId=Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese Su Identificacion"));
		objetoPersona.setId(temporalId);	
		
		//utilizo el atributo "atributoPersona" del tipo de dato (clase) Persona para guardar la información
		this.atributoPersona=objetoPersona;
		
	}
	
	public void preguntarPreguntas() {
		Preguntas objetoPregunta=new Preguntas();
		int temporalPregunta1,temporalPregunta2;
		
		temporalPregunta1=Integer.parseInt(JOptionPane.showInputDialog(null,"En una escala de 1 a 5, te gusta programar?"));
		temporalPregunta2=Integer.parseInt(JOptionPane.showInputDialog(null,"En una escala de 1 a 5, te gusta La matematica?"));
		
		objetoPregunta.inicializarPuntajes(1,temporalPregunta1);
		objetoPregunta.inicializarPuntajes(2,temporalPregunta2);
		
		this.atributoPregunta=objetoPregunta;
		
	}
	
	public void mostrarRespuestas() {
		
		String nombre=this.atributoPersona.getNombre();
		int edad=this.atributoPersona.getEdad();
		
		int resultado=this.atributoPregunta.puntajeTotal();
		
		JOptionPane.showMessageDialog(null,"El nombre es:"+nombre+" La edad es:"+edad+" El resultado es:"+resultado);
		
		
	}
	
}
