package otroEjemplo;

public class Preguntas {
	//Declarando atributos
	//La función de éste atributo es la de servir como variable para guardar el total de puntaje
	private int puntajeTotal;
	private int puntajePregunta1;
	private int puntajePregunta2;
	
	
	//Metodos
	public void inicializarPuntajes(int entradaPregunta,int entradaPuntajePregunta) {
		/*
		 * 1. te gusta la matematica
		 * 2. te gusta programar*/
		switch(entradaPregunta) {
		case 1:
			puntajePregunta1=entradaPuntajePregunta;
		case 2:
			puntajePregunta2=entradaPuntajePregunta;
		}
	}
	
	public int puntajeTotal() {
		puntajeTotal=puntajePregunta1+puntajePregunta2;
		return puntajeTotal;
	}

}
