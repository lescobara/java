package sobrecargaConstructor;

public class AvionHijo extends Avion{

	public AvionHijo(String entradaMarca) {
		super(entradaMarca);
		// TODO Auto-generated constructor stub
	}
	

}
