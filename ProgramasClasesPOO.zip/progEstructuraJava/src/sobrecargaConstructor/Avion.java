package sobrecargaConstructor;

public class Avion {
	
	//Atributos
	private String marca;
	private int cantidadMotores;
	private String color;
	
	//Crear constructor
	public Avion(String entradaMarca,int entradaCantidadMotores, String entradaColor) {
		this.marca=entradaMarca;
		this.cantidadMotores=entradaCantidadMotores;
		this.color=entradaColor;
		
	}
	
	public Avion (String entradaMarca) {
		this.marca=entradaMarca;
	}

}
