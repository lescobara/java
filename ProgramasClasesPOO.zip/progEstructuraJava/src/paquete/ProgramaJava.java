package paquete;


public class ProgramaJava {
	
	//Atributos - Características que tiene nuestra clase
	public String marca;
	public String tipoProcesador;
	public String marcaProcesador;
	private String marcaBoard;
	private int fabricacion;
	private String tipoDiscoDuro;
	private int capacidadDiscoDuro;
	private float cantidadRam;
	
	//Metodos - Las acciones que realiza nuestra clase
	//Al momento de declarar un método es importante lo siguiente:
	//1. El tipo de dato que devuelve (nada o que devuelva un String, un int, un float, etc)
	//2. El nombre de la función o método
	//3. La visibilidad del método public, privado, abstracto
	//4. El tipo de dato que recibe de entrada (nada o que reciba un String, un int, un float, etc)
	
	public void ejecutarPrograma (String nombrePrograma, int entradaTiempo) {
		for (int i=1;i<=entradaTiempo;i++) {
			System.out.println("Ejecutando programa:"+nombrePrograma);
		}
	}
	
	public String cerrarPrograma (String nombrePrograma,String entradaMotivo) {
		System.out.println("Cerrando el programa:"+nombrePrograma);
		return entradaMotivo;
	}
	
	public void guardarDatos (String entradaMarca,String entradaTipoProcesador,String entradaMarcaProcesador,float entradaCantidadRam) {
		marca=entradaMarca;
		tipoProcesador=entradaTipoProcesador;
		marcaProcesador=entradaMarcaProcesador;
		cantidadRam=entradaCantidadRam;
	}

	//El método GET sirve para obtener el valor del atributo
	public float getCantidadRam() {
		return cantidadRam;
	}
	//El método SET se emplea para inicializar el atributo. 
	public void setCantidadRam(float cantidadRam) {
		this.cantidadRam = cantidadRam;
	}

	public String getMarcaBoard() {
		return marcaBoard;
	}

	public void setMarcaBoard(String marcaBoard) {
		this.marcaBoard = marcaBoard;
	}
	
	
	
	/*pie de página NO es necesario que Todas las clases tengan
	 * una función Principal (main)*/
}
