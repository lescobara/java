package paquete;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ClasePrincipal {

	//Función PPAL
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		String retorno;
		String entradaMarcaBoard;
		
		//creando un objeto del tipo ProgramaJava
		//Instanciando un objeto de la clase ProgramaJava
		ProgramaJava objetoCualquiera=new ProgramaJava(); 
		
		//Accediendo a un método
		objetoCualquiera.guardarDatos("clon","CISC","AMD-Ryzen",32);
		
		System.out.println("La marca del procesador es:"+objetoCualquiera.marcaProcesador);
		System.out.println("El tipo de procesador es:"+objetoCualquiera.tipoProcesador);
		System.out.println("La marca del computador es:"+objetoCualquiera.marca);
		System.out.println("La cantidad de memoria RAM es"+objetoCualquiera.getCantidadRam());
		
		objetoCualquiera.ejecutarPrograma("Fornite",10);
		
		retorno=objetoCualquiera.cerrarPrograma("Chrome","Cerrar por decision del usuario");
		System.out.println("el motivo del cierre del programa es: "+retorno);
		
		System.out.println("Por favor, digite la Marca de la board");
		//Crear TODO lo NECESARIO para poder capturar información desde la consola: 
		//1. Crear un objeto del tipo BufferReader
		BufferedReader objetoEntrada=new BufferedReader(new InputStreamReader(System.in));
		//2. Lo que captura mi objeto de BufferedReader lo almaceno en la variable tipo String entradaMarcaBoard
		entradaMarcaBoard=objetoEntrada.readLine();
	
		//Utilizo el Método SEt para inicializar el atributo marcaBoard
		objetoCualquiera.setMarcaBoard(entradaMarcaBoard);
		
		//Utilizo el método GET para obtener el valor del atributo marcaBoard
		System.out.println("La marca de la board es: "+objetoCualquiera.getMarcaBoard());
		
		

	}

}
