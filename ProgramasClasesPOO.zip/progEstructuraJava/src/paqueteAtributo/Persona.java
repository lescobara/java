package paqueteAtributo;

public class Persona {
	private String nombre;
	private String apellido;
	private int edad;
	
	public void caminar() {
		System.out.println("Estoy caminando");
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
