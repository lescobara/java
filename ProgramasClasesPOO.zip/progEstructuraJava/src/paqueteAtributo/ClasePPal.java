package paqueteAtributo;

public class ClasePPal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Persona objetoPersona=new Persona();
		
		objetoPersona.setNombre("Condorito");
		System.out.println("El nombre de la Persona es"+objetoPersona.getNombre());
		
	}

}
